Nothing to copy
